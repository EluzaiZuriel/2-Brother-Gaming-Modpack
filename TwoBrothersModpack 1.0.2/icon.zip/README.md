## This is a Mod Pack with 59 other dependent Mods for the Server Two Brothers Gaming.
 
+ For this to run correctly with the server please rollback to old valheim.
   - Right click on Valheim in Steam, select properties, select BETAS and select default_old - Previous stable

---
+ This is currently a private server
---

### V1.0.2

   - Valheim+ has been removed and more mods have been added.

### v1.0.1

   - New Version of Two Brothers Modpack
   - Certain mods in the modpack have been changed to work with Valheim+ and the previous version of Valheim

### V1.0.0

   - Initial Release